Artwork is from a free licence from http://emojione.com
